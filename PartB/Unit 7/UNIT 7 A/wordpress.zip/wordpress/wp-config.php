<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the installation.
 * You don't have to use the web site, you can copy this file to "wp-config.php"
 * and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * Database settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://wordpress.org/support/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** Database settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'wordpress' );

/** Database username */
define( 'DB_USER', 'root' );

/** Database password */
define( 'DB_PASSWORD', '' );

/** Database hostname */
define( 'DB_HOST', 'localhost' );

/** Database charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The database collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication unique keys and salts.
 *
 * Change these to different unique phrases! You can generate these using
 * the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}.
 *
 * You can change these at any point in time to invalidate all existing cookies.
 * This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         'Z!Hsek8w IZ)CD+8/oXHIJFggL34pA?Odpn^8=[GaX[?A4+FLw<=*,l1?^pge9au' );
define( 'SECURE_AUTH_KEY',  '7]URh^3X~NQs}jykmCN$xJEip#S$5U;H4VmdkSgh1fI7_bW-XHjn%+ShYfivSG.]' );
define( 'LOGGED_IN_KEY',    'Tv7{_l6/Ao#&IF9,d`W=F/,UCAq9 cn<HKVV=jhZ:EVhETh]Ul2Y&WuCm$l(WKoi' );
define( 'NONCE_KEY',        'J@o7V&.QK2,ux2>T^mL2E`[aWr,0pZgBo9H5ZL**h:p%+9FNOmc64|LBpaN&Fl,F' );
define( 'AUTH_SALT',        'u%MxnFqXh|nyi%4+dunj#9){>K!T;_d5Iz_iH8l$_Wz@r2p?5N9z]4KY*iqw1v>.' );
define( 'SECURE_AUTH_SALT', '*DNvJlgcLS.$<5XLJyiHz8fw~Jq!Y?hXV]AhXs:En__wNBN?Rs0JAB``g<6<$-;_' );
define( 'LOGGED_IN_SALT',   'eHa.3x={/gs, a[ft]bzx[ ?X5zv~<C~0DSlx5-2tYOB31a|?iTmyU.4xjrBrk*d' );
define( 'NONCE_SALT',       'HV3d!Nha:,379nO`%:[h9MGE!#43P@j,y%bBLHwpF169*d&Y,^oGt.rEASYGssk%' );

/**#@-*/

/**
 * WordPress database table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://wordpress.org/support/article/debugging-in-wordpress/
 */
define( 'WP_DEBUG', false );

/* Add any custom values between this line and the "stop editing" line. */



/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
